#include "gd32f4xx.h"
#include "systick.h"
#include <stdio.h>
#include <string.h>
#include "main.h"

#include "USART0.h"

/*******************************************
����Ŀ�꣺�����������ȼ���Ӧ���ȼ���ͬ������ռ���ȼ���ͬ��״�����۲촮��������
*******************************************/
void USART0_on_recv(uint8_t *buffer, uint32_t len)
{
  // printf("recv[%d]-> %s\n", len, buffer);
  switch (buffer[0])
  {
  case 0x00:
    exti_software_interrupt_enable(EXTI_0);
    break;
  case 0x01:
    exti_software_interrupt_enable(EXTI_1);
    break;
  case 0x02:
    exti_software_interrupt_enable(EXTI_2);
    break;
  default:
    break;
  }
}

// �ж����ȼ�����
#define EXTI0_PRIORITY 1, 0
#define EXTI1_PRIORITY 2, 0
#define EXTI2_PRIORITY 3, 0

void EXTI0_config()
{
  // EXTI
  rcu_periph_clock_enable(RCU_SYSCFG);

  exti_init(EXTI_0, EXTI_INTERRUPT, EXTI_TRIG_NONE);

  nvic_irq_enable(EXTI0_IRQn, EXTI0_PRIORITY);
  exti_interrupt_enable(EXTI_0);

  exti_interrupt_flag_clear(EXTI_0);
}

void EXTI1_config()
{
  // EXTI
  rcu_periph_clock_enable(RCU_SYSCFG);

  exti_init(EXTI_1, EXTI_INTERRUPT, EXTI_TRIG_NONE);

  nvic_irq_enable(EXTI1_IRQn, EXTI1_PRIORITY);
  exti_interrupt_enable(EXTI_1);

  exti_interrupt_flag_clear(EXTI_1);
}

void EXTI2_config()
{
  // EXTI
  rcu_periph_clock_enable(RCU_SYSCFG);

  exti_init(EXTI_2, EXTI_INTERRUPT, EXTI_TRIG_NONE);

  nvic_irq_enable(EXTI2_IRQn, EXTI2_PRIORITY);
  exti_interrupt_enable(EXTI_2);

  exti_interrupt_flag_clear(EXTI_2);
}

void EXTI0_IRQHandler()
{
  if (SET == exti_interrupt_flag_get(EXTI_0))
  {
    exti_interrupt_flag_clear(EXTI_0);
    printf("EXTI_0 HeadMaster\n");
    for (uint8_t i = 0; i < 10; i++)
    {
      printf("EXTI_0 HeadMaster: %d\n", i);
      delay_1ms(500);
    }
  }
}

void EXTI1_IRQHandler()
{
  if (SET == exti_interrupt_flag_get(EXTI_1))
  {
    exti_interrupt_flag_clear(EXTI_1);
    printf("EXTI_1 Teacher\n");
    for (uint8_t i = 0; i < 10; i++)
    {
      printf("EXTI_1 Teacher: %d\n", i);
      delay_1ms(500);
    }
  }
}

void EXTI2_IRQHandler()
{
  if (SET == exti_interrupt_flag_get(EXTI_2))
  {
    exti_interrupt_flag_clear(EXTI_2);
    printf("EXTI_2 Students\n");
    for (uint8_t i = 0; i < 10; i++)
    {
      printf("EXTI_2 Students: %d\n", i);
      delay_1ms(500);
    }
  }
}
int main(void)
{
  systick_config();
  EXTI0_config();
  EXTI1_config();
  EXTI2_config();
  USART0_init();

  while (1)
  {
    delay_1ms(500);
  }
}