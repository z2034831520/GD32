#ifndef __LIB_BUZZER_H__
#define __LIB_BUZZER_H__
#include "gd32f4xx.h"
#include "systick.h"
#include "LED.h"

void buzzer_config(void);
void buzzer_running_10ms(uint16_t freq);
#endif