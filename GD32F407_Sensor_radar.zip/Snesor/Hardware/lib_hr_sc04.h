#ifndef __LIB_HR_SC04_H__
#define __LIB_HR_SC04_H__

#include "gd32f4xx.h"
#include "systick.h"
//初始化传感器
void hr_sc04_config(void);

//获取物体距离
float hr_sc04_get_distance(void);

//计数器加加
void hr_sc04_counter_increment(void);
#endif