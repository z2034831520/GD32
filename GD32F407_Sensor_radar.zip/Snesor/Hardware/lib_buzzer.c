#include "lib_buzzer.h"

void buzzer_config(void)
{
    rcu_periph_clock_enable(RCU_GPIOB);
    gpio_mode_set(GPIOB, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_9);
    gpio_output_options_set(GPIOB, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, GPIO_PIN_9);
}


void buzzer_running_10ms(uint16_t freq)
{
    uint16_t i;
    for (i = 0; i < (freq/100); i++)
    {
        gpio_bit_set(GPIOB, GPIO_PIN_9);
        On_LED();
        delay_1us(1000000 / freq / 2);

        Off_LED();
        gpio_bit_reset(GPIOB, GPIO_PIN_9);
        delay_1us(1000000 / freq / 2);

    }
}