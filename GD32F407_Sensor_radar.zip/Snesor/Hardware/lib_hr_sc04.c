#include "lib_hr_sc04.h"

uint32_t counter = 0;
// 初始化传感器
void hr_sc04_config()
{
    //gpio初始化
    rcu_periph_clock_enable(RCU_GPIOC);
    
    //PC6
    gpio_mode_set(GPIOC, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_6);
    gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_6);
    gpio_bit_reset(GPIOC, GPIO_PIN_6);

    //PC7   输入模式 下拉输入（默认为低电平）
    gpio_mode_set(GPIOC, GPIO_MODE_INPUT, GPIO_PUPD_PULLDOWN, GPIO_PIN_7);
}

// 获取物体距离
float hr_sc04_get_distance()
{
    uint16_t timeout = 30000;       //300000us
    uint16_t curr_timeout = 0;
    float distance_cm;
    gpio_bit_set(GPIOC, GPIO_PIN_6);
    delay_1us(20);
    gpio_bit_reset(GPIOC, GPIO_PIN_6);

    //阻塞到拉高为止
    while(0 == gpio_input_bit_get(GPIOC, GPIO_PIN_7) && curr_timeout < timeout)
    {
        //退出循环：1.拉高了 2.当前时间累加超过最大值
        delay_1us(1);
        curr_timeout++;
    }

    if (curr_timeout >= timeout)
    {
        //判断退出原因
        return -1;
        //返回-1表示超时
    }

    //如果执行到这里表明一切正常
    //开始统计高电平持续时间
    counter = 0;

    while(1 == gpio_input_bit_get(GPIOC, GPIO_PIN_7));
    //上面while循环结束说明得到低电平信号
    //float类型
    distance_cm = counter / 58.0f;

    //测量范围2cm - 400cm
    if (distance_cm < 2)
    {
        return 2;
    }
    else if(distance_cm > 400)
    {
        return 400;
    }
    return distance_cm;
}

void hr_sc04_counter_increment(void)
{
    counter++;
}