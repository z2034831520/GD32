#ifndef __USART0_H__
#define __USART0_H__

#include "gd32f4xx.h"
#include <stdio.h>

void usart0_config(void);
void send_byte(uint8_t data);
int fputc(int ch, FILE *f);

#endif