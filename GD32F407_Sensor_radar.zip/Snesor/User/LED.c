#include "LED.h"

// ����gpio��ʼ����������Ľṹ��
typedef struct {
	rcu_periph_enum rcu;
	uint32_t port;
	uint32_t pin;
} Led_GPIO_t;

// ��������gpio��Ӧ����������
Led_GPIO_t g_gpio_list[] = {
    {RCU_GPIOC, GPIOC, GPIO_PIN_6},  // LED_SW
    {RCU_GPIOD, GPIOD, GPIO_PIN_8},  // LED1
    {RCU_GPIOD, GPIOD, GPIO_PIN_9},  // LED2
    {RCU_GPIOD, GPIOD, GPIO_PIN_10}, // LED3
    {RCU_GPIOD, GPIOD, GPIO_PIN_11}, // LED4
    {RCU_GPIOD, GPIOD, GPIO_PIN_12}, // LED5
    {RCU_GPIOD, GPIOD, GPIO_PIN_13}, // LED6
    {RCU_GPIOD, GPIOD, GPIO_PIN_14}, // LED7
    {RCU_GPIOD, GPIOD, GPIO_PIN_15}  // LED8
};

// ���ڼ������鳤�ȵĺ�
#define MAX_LED_COUNT	(sizeof(g_gpio_list) / sizeof(Led_GPIO_t))

/**********************************************************
 * @brief LED GPIO��ʼ��
 **********************************************************/
static void LED_GPIO_config(rcu_periph_enum rcu, uint32_t port, uint32_t pin){
	// ��ʼ��Ϊ�������ģʽ
	rcu_periph_clock_enable(rcu);
	gpio_mode_set(port, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, pin);
	gpio_output_options_set(port, GPIO_OTYPE_PP, GPIO_OSPEED_MAX, pin);
}

void bsp_leds_init(){

	uint8_t count = MAX_LED_COUNT;
	for(uint8_t i = 0; i < count; i++){
		Led_GPIO_t gpio = g_gpio_list[i];
		// ��ʼ��
		LED_GPIO_config(gpio.rcu,gpio.port, gpio.pin);
		// Ĭ��ȫ������(�ر�)
		gpio_bit_write(gpio.port, gpio.pin, SET);
	}

	// �ܿ�������(��)
	gpio_bit_write(g_gpio_list[0].port, g_gpio_list[0].pin, RESET);
}

// ����
void bsp_led_turn_on(uint8_t led_index){
		Led_GPIO_t gpio = g_gpio_list[led_index];
		gpio_bit_write(gpio.port, gpio.pin, RESET);
}

// �ص�
void bsp_led_turn_off(uint8_t led_index){
		Led_GPIO_t gpio = g_gpio_list[led_index];
		gpio_bit_write(gpio.port, gpio.pin, SET);
}
void bsp_fluid_sequential(uint32_t delay_ms)
{
	// ��LED1��ʼ��LED8˳�����
	for (uint8_t i = 1; i < MAX_LED_COUNT; i++)
	{
		bsp_led_turn_on(i);	 // ������ǰLED
		delay_1ms(delay_ms); // ��ʱ
		bsp_led_turn_off(i); // Ϩ��ǰLED
	}
}

void bsp_twinkle_LED(uint32_t delay_ms)
{
	for (uint8_t i = 1; i < MAX_LED_COUNT; i++)
	{
		if (i % 2 == 0)
		{
			bsp_led_turn_on(LED1);
			bsp_led_turn_on(LED2);
			bsp_led_turn_on(LED3);
			bsp_led_turn_on(LED4);
			bsp_led_turn_on(LED5);
			bsp_led_turn_on(LED6);
			bsp_led_turn_on(LED7);
			bsp_led_turn_on(LED8);
			delay_1ms(delay_ms);
		}
		else
		{
			bsp_led_turn_off(LED1);
			bsp_led_turn_off(LED2);
			bsp_led_turn_off(LED3);
			bsp_led_turn_off(LED4);
			bsp_led_turn_off(LED5);
			bsp_led_turn_off(LED6);
			bsp_led_turn_off(LED7);
			bsp_led_turn_off(LED8);
			delay_1ms(delay_ms);
		}

	}
}

/**
 * @brief ������ˮ��Ч��
 * @param delay_ms: ÿ��״̬����ʱʱ��
 */
void bsp_fluid_round_trip(uint32_t delay_ms)
{
	// ��������
	for (uint8_t i = 1; i < MAX_LED_COUNT; i++)
	{
		bsp_led_turn_on(i);
		delay_1ms(delay_ms);
		bsp_led_turn_off(i);
	}

	// ��������
	for (uint8_t i = MAX_LED_COUNT - 1; i >= 1; i--)
	{
		bsp_led_turn_on(i);
		delay_1ms(delay_ms);
		bsp_led_turn_off(i);
	}
}

void On_LED()
{
	bsp_led_turn_on(LED1);
	bsp_led_turn_on(LED2);
	bsp_led_turn_on(LED3);
	bsp_led_turn_on(LED4);
	bsp_led_turn_on(LED5);
	bsp_led_turn_on(LED6);
	bsp_led_turn_on(LED7);
	bsp_led_turn_on(LED8);
}

void Off_LED()
{
	bsp_led_turn_off(LED1);
	bsp_led_turn_off(LED2);
	bsp_led_turn_off(LED3);
	bsp_led_turn_off(LED4);
	bsp_led_turn_off(LED5);
	bsp_led_turn_off(LED6);
	bsp_led_turn_off(LED7);
	bsp_led_turn_off(LED8);
}
void Turn_On_ALL_LED(uint16_t time)
{
	On_LED();
	delay_1ms(time);
	Off_LED();

}