#ifndef __BSP_LEDS_H__
#define __BSP_LEDS_H__

#include "gd32f4xx.h"

#define LED_SW	GPIOC, GPIO_PIN_6
#define LED1		GPIOD, GPIO_PIN_8 
#define LED3		GPIOD, GPIO_PIN_10
#define LED5		GPIOD, GPIO_PIN_12
#define LED7		GPIOD, GPIO_PIN_14

#define LED1_ON()		gpio_bit_reset(LED1)
#define LED1_OFF()	gpio_bit_set(LED1)

#define LED3_ON()		gpio_bit_reset(LED3)
#define LED3_OFF()	gpio_bit_set(LED3)

void Leds_init();

void Leds_turn_on(uint8_t index);

void Leds_turn_off(uint8_t index);


#endif