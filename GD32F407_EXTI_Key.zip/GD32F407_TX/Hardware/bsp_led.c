#include "bsp_leds.h"

static void GPIO_config(rcu_periph_enum rcu, uint32_t port, uint32_t pin ) {
	// ��ʼ��LED, �������
	// ʱ�ӳ�ʼ��
  rcu_periph_clock_enable(rcu);
	// ����GPIOģʽ�����ģʽ
  gpio_mode_set(port, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, pin);
  // �������ѡ�PP���죬����ٶ�
	gpio_output_options_set(port, GPIO_OTYPE_PP, GPIO_OSPEED_MAX, pin);
	// Ĭ�Ϲر�(����)
	gpio_bit_write(port, pin, SET);
}


void Leds_init(){
	GPIO_config(RCU_GPIOC, LED_SW);
	GPIO_config(RCU_GPIOD, LED1);
	GPIO_config(RCU_GPIOD, LED3);
	GPIO_config(RCU_GPIOD, LED5);
	GPIO_config(RCU_GPIOD, LED7);
	
	// �����ܿ���
	gpio_bit_write(LED_SW, RESET);
	
}

void Leds_turn_on(uint8_t index){
	switch (index)
  {
  	case 0: gpio_bit_reset(LED1); break;
  	case 1: gpio_bit_reset(LED3); break;
  	case 2: gpio_bit_reset(LED5); break;
  	case 3: gpio_bit_reset(LED7); break;
  	default: break;
  }
}
void Leds_turn_off(uint8_t index){
	switch (index)
  {
  	case 0: gpio_bit_set(LED1); break;
  	case 1: gpio_bit_set(LED3); break;
  	case 2: gpio_bit_set(LED5); break;
  	case 3: gpio_bit_set(LED7); break;
  	default: break;
  }

}