#ifndef __LED_H__
#define __LED_H__

#include "gd32f4xx.h"
#include "systick.h"

#define LED1	1
#define LED2	2
#define LED3	3
#define LED4	4
#define LED5    5
#define LED6    6
#define LED7    7
#define LED8    8

void bsp_leds_init();

void bsp_led_turn_on(uint8_t led_index);

void bsp_led_turn_off(uint8_t led_index);
void bsp_fluid_sequential(uint32_t delay_ms);
void bsp_twinkle_LED(uint32_t delay_ms);
void bsp_fluid_round_trip(uint32_t delay_ms);
void On_LED(void);
#endif