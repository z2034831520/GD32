#include "exti0.h"

void exti0_config()
{
	//GPIO PA0输入模式
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOC);
    gpio_mode_set(GPIOA, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO_PIN_0);
    gpio_mode_set(GPIOC, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO_PIN_0);
    gpio_mode_set(GPIOC, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO_PIN_1);
    gpio_mode_set(GPIOC, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO_PIN_2);
    gpio_mode_set(GPIOC, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO_PIN_3);

    //EXTI初始化
    rcu_periph_clock_enable(RCU_SYSCFG);                //上钟
    syscfg_exti_line_config(EXTI_SOURCE_GPIOC, EXTI_SOURCE_PIN0);   //设置终端类型为外部中断
    exti_init(EXTI_0, EXTI_INTERRUPT, EXTI_TRIG_RISING);            //设置触发模式为上升沿触发
    nvic_irq_enable(EXTI0_IRQn, 1, 1);                              //设置优先级（抢占优先级，相应优先级）
    exti_interrupt_enable(EXTI_0);                                  //外部终端通道0开启
    exti_interrupt_flag_clear(EXTI_0);                              //清理外部中断的flag标记全新开始

    syscfg_exti_line_config(EXTI_SOURCE_GPIOC, EXTI_SOURCE_PIN1);
    exti_init(EXTI_1, EXTI_INTERRUPT, EXTI_TRIG_FALLING); // 设置触发模式为上升沿触发
    nvic_irq_enable(EXTI1_IRQn, 1, 2);                   // 设置优先级（抢占优先级，相应优先级）
    exti_interrupt_enable(EXTI_1);                       // 外部终端通道0开启
    exti_interrupt_flag_clear(EXTI_1);                   // 清理外部中断的flag标记全新开始

    syscfg_exti_line_config(EXTI_SOURCE_GPIOC, EXTI_SOURCE_PIN2);
    exti_init(EXTI_2, EXTI_INTERRUPT, EXTI_TRIG_FALLING); // 设置触发模式为上升沿触发
    nvic_irq_enable(EXTI2_IRQn, 1, 3);                    // 设置优先级（抢占优先级，相应优先级）
    exti_interrupt_enable(EXTI_2);                        // 外部终端通道0开启
    exti_interrupt_flag_clear(EXTI_2);                    // 清理外部中断的flag标记全新开始

    syscfg_exti_line_config(EXTI_SOURCE_GPIOC, EXTI_SOURCE_PIN3);
    exti_init(EXTI_3, EXTI_INTERRUPT, EXTI_TRIG_FALLING); // 设置触发模式为上升沿触发
    nvic_irq_enable(EXTI3_IRQn, 1, 4);                    // 设置优先级（抢占优先级，相应优先级）
    exti_interrupt_enable(EXTI_3);                        // 外部终端通道0开启
    exti_interrupt_flag_clear(EXTI_3);                    // 清理外部中断的flag标记全新开始
}