#ifndef __EXTI0_H__
#define __EXTI0_H__

#include "gd32f4xx.h"

void exti0_config(void);
#endif