工程说明：
	
引脚接线：

各文件目录说明：
	User：系统文件，包括main.c、systick.c、gd32f4xx_it.c
	Project：工程生成的文件，包括工程启动项、hex文件、编译文件
	Hardware：自己添加的各类底层驱动文件
	Firmware：官方标准库
	Doc：工程说明文档